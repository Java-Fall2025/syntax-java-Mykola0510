package app.concurrency;

import app.model.Student;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Processor {

    private static final Logger logger = Logger.getLogger(Processor.class.getName());

    public static Callable<List<Student>> filterByMinAgeCallable(List<Student> source, int minAge) {
        return () -> {
            logger.info("Callable start: filterByMinAge(" + minAge + ") - thread: " + Thread.currentThread().getName());
            List<Student> res = source.stream()
                    .filter(s -> s.getAge() >= minAge)
                    .collect(Collectors.toList());
            logger.info("Callable done: " + res.size() + " students (minAge=" + minAge + ")");
            return res;
        };
    }

    public static Runnable countByPrefixRunnable(List<Student> source, String prefix, java.util.concurrent.atomic.AtomicInteger out) {
        return () -> {
            logger.info("Runnable start: countByPrefix('" + prefix + "') - thread: " + Thread.currentThread().getName());
            long cnt = source.stream().filter(s -> s.getName().startsWith(prefix)).count();
            out.addAndGet((int)cnt);
            logger.info("Runnable done: prefix='" + prefix + "' count=" + cnt);
        };
    }
}
