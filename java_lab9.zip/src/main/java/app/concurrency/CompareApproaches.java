package app.concurrency;

import app.model.Student;

import java.util.List;
import java.util.concurrent.*;
import java.util.logging.Logger;

public class CompareApproaches {

    private static final Logger logger = Logger.getLogger(CompareApproaches.class.getName());

    public static long measureParallelStream(List<Student> data, int minAge) {
        long start = System.nanoTime();
        long count = data.parallelStream().filter(s -> s.getAge() >= minAge).count();
        long elapsed = System.nanoTime() - start;
        logger.info("parallelStream count=" + count + " time(ns)=" + elapsed);
        return elapsed;
    }

    public static long measureExecutorService(List<Student> data, int minAge) throws InterruptedException, ExecutionException {
        long start = System.nanoTime();
        int threads = Math.min(4, Runtime.getRuntime().availableProcessors());
        ExecutorService exec = Executors.newFixedThreadPool(threads);
        try {
            int chunk = Math.max(1, data.size() / threads);
            List<Callable<Long>> tasks = new java.util.ArrayList<>();
            for (int i=0;i<threads;i++) {
                final int from = i*chunk;
                final int to = (i==threads-1)? data.size() : Math.min(data.size(), (i+1)*chunk);
                tasks.add(() -> data.subList(from,to).stream().filter(s -> s.getAge() >= minAge).count());
            }
            List<Future<Long>> futures = exec.invokeAll(tasks);
            long total = 0;
            for (Future<Long> f: futures) total += f.get();
            long elapsed = System.nanoTime() - start;
            logger.info("ExecutorService count=" + total + " time(ns)=" + elapsed);
            return elapsed;
        } finally {
            exec.shutdown();
        }
    }
}
