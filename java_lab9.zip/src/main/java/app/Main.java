package app;

import app.concurrency.CompareApproaches;
import app.concurrency.Processor;
import app.model.Student;
import app.repository.FileStudentRepository;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) throws Exception {
        FileStudentRepository repo = new FileStudentRepository();

        List<Path> files = Arrays.asList(
                Paths.get("data/students1.txt"),
                Paths.get("data/students2.txt"),
                Paths.get("data/students3.txt")
        );

        // Parallel loading using CompletableFuture
        repo.loadFromFilesParallel(files);

        logger.info("Total students after CompletableFuture load: " + repo.size());

        // Demonstrate parallelStream loading too (on fresh repo)
        FileStudentRepository repo2 = new FileStudentRepository();
        repo2.loadFromFilesParallelStream(files);
        logger.info("Total students after parallelStream load: " + repo2.size());

        // Prepare data for processing
        List<Student> all = repo.getAll();

        // ExecutorService + Callable
        ExecutorService exec = Executors.newFixedThreadPool(3);
        try {
            Callable<List<Student>> task = Processor.filterByMinAgeCallable(all, 20);
            Future<List<Student>> future = exec.submit(task);
            List<Student> filtered = future.get();
            logger.info("Filtered (age>=20) size: " + filtered.size());

            // Runnable counting by prefix
            AtomicInteger sum = new AtomicInteger(0);
            Runnable r1 = Processor.countByPrefixRunnable(all, "A", sum);
            Runnable r2 = Processor.countByPrefixRunnable(all, "O", sum);
            exec.submit(r1);
            exec.submit(r2);

            // measure approaches
            long t1 = CompareApproaches.measureParallelStream(all, 20);
            long t2 = CompareApproaches.measureExecutorService(all, 20);
            logger.info("Timing: parallelStream(ns)=" + t1 + ", executor(ns)=" + t2);
        } finally {
            exec.shutdown();
        }

        // CompletableFuture chaining example
        CompletableFuture<List<Student>> cf = CompletableFuture.supplyAsync(() -> repo.getAll())
                .thenApplyAsync(list -> list.stream().filter(s -> s.getAge() >= 21).collect(Collectors.toList()))
                .handle((res, ex) -> {
                    if (ex != null) {
                        logger.severe("Error in CompletableFuture chain: " + ex);
                        return java.util.Collections.emptyList();
                    } else {
                        logger.info("CompletableFuture chain result size: " + res.size());
                        return res;
                    }
                });

        List<Student> cfRes = cf.get();
        logger.info("Final CF result size: " + cfRes.size());
    }
}
