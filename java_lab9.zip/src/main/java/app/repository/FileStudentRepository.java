package app.repository;

import app.model.Student;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileStudentRepository extends StudentRepository {

    private static final Logger logger = Logger.getLogger(FileStudentRepository.class.getName());

    public void loadFromFilesParallel(List<Path> paths) {
        logger.info("Loading from files in parallel using CompletableFuture...");
        ExecutorService exec = Executors.newFixedThreadPool(Math.min(paths.size(), Runtime.getRuntime().availableProcessors()));
        try {
            List<CompletableFuture<Void>> futures = paths.stream()
                    .map(p -> CompletableFuture.runAsync(() -> loadFromFile(p), exec)
                            .exceptionally(ex -> {
                                logger.severe("Error loading file " + p + ": " + ex);
                                return null;
                            }))
                    .collect(Collectors.toList());

            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        } finally {
            exec.shutdown();
        }
    }

    private void loadFromFile(Path p) {
        logger.info("Start loading file: " + p);
        try (BufferedReader br = Files.newBufferedReader(p)) {
            br.lines()
                    .filter(l -> !l.isBlank())
                    .forEach(line -> {
                        // expected format: name,age
                        String[] parts = line.split(",");
                        if (parts.length >= 2) {
                            try {
                                Student s = new Student(parts[0].trim(), Integer.parseInt(parts[1].trim()));
                                // add is synchronized in parent
                                add(s);
                            } catch (Exception e) {
                                logger.warning("Skipping invalid line in " + p + ": '" + line + "' -> " + e.getMessage());
                            }
                        } else {
                            logger.warning("Bad line format in " + p + ": '" + line + "'");
                        }
                    });
        } catch (IOException e) {
            logger.severe("IO error reading " + p + ": " + e.getMessage());
        }
        logger.info("Finished loading file: " + p);
    }

    // alternative method using parallelStream for comparison
    public void loadFromFilesParallelStream(List<Path> paths) {
        logger.info("Loading from files using parallelStream...");            
        paths.parallelStream().forEach(this::loadFromFile);
    }
}
