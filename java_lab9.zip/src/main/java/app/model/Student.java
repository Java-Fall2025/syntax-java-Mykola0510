package app.model;

import app.exception.InvalidDataException;
import app.validator.ValidationUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Student implements Comparable<Student> {

    private static final Logger logger = Logger.getLogger(Student.class.getName());

    private String name;
    private int age;

    public Student(String name, int age) {
        List<String> errors = new ArrayList<>();

        errors.addAll(ValidationUtils.validateString(name, "name"));
        errors.addAll(ValidationUtils.validatePositiveInt(age, "age"));

        if (!errors.isEmpty()) {
            logger.warning("Invalid Student creation attempt: " + errors);
            throw new InvalidDataException(errors);
        }

        this.name = name;
        this.age = age;

        logger.info("Student created successfully: " + this);
    }

    public void setName(String name) {
        List<String> errors = ValidationUtils.validateString(name, "name");

        if (!errors.isEmpty()) {
            logger.warning("Invalid setName(): " + errors);
            throw new InvalidDataException(errors);
        }

        this.name = name;
        logger.info("Name updated: " + name);
    }

    public void setAge(int age) {
        List<String> errors = ValidationUtils.validatePositiveInt(age, "age");

        if (!errors.isEmpty()) {
            logger.warning("Invalid setAge(): " + errors);
            throw new InvalidDataException(errors);
        }

        this.age = age;
        logger.info("Age updated: " + age);
    }

    public String getName() { return name; }
    public int getAge() { return age; }

    @Override
    public int compareTo(Student o) {
        return this.name.compareTo(o.name);
    }

    @Override
    public String toString() {
        return name + " (" + age + ")";
    }
}
