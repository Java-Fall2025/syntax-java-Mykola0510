package app.validator;

import java.util.ArrayList;
import java.util.List;

public class ValidationUtils {

    public static List<String> validateString(String value, String field) {
        List<String> errors = new ArrayList<>();
        if (value == null || value.isBlank()) {
            errors.add(field + ": cannot be null or empty");
        }
        return errors;
    }

    public static List<String> validatePositiveInt(int value, String field) {
        List<String> errors = new ArrayList<>();
        if (value <= 0) {
            errors.add(field + ": must be > 0");
        }
        return errors;
    }
}
