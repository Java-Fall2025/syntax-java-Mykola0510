package app;

import app.model.Student;
import app.repository.FileStudentRepository;
import org.junit.jupiter.api.Test;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ConcurrencyTests {

    @Test
    void parallelLoadPopulatesRepository() {
        FileStudentRepository repo = new FileStudentRepository();
        List<java.nio.file.Path> files = Arrays.asList(
                Paths.get("data/students1.txt"),
                Paths.get("data/students2.txt"),
                Paths.get("data/students3.txt")
        );
        repo.loadFromFilesParallel(files);
        assertTrue(repo.size() >= 9, "Expected at least 9 students loaded in parallel"); // we put 9 lines across files
    }

    @Test
    void processingResultsMatchExpected() {
        FileStudentRepository repo = new FileStudentRepository();
        List<java.nio.file.Path> files = Arrays.asList(
                Paths.get("data/students1.txt"),
                Paths.get("data/students2.txt"),
                Paths.get("data/students3.txt")
        );
        repo.loadFromFilesParallel(files);
        List<Student> all = repo.getAll();
        long cnt = all.stream().filter(s -> s.getAge() >= 20).count();
        assertTrue(cnt > 0, "There should be some students age >=20");
    }
}
