package ua.model.enums;

public enum EBookType { PUBLIC, RESTRICTED }
