package ua.model.enums;

public enum EBookFormat { PDF, EPUB, MOBI }
