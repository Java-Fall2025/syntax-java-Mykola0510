package ua.model;

public record Author(String firstName, String lastName, int birthYear) { }
