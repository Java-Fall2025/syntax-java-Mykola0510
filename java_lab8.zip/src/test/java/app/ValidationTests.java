package app;

import app.exception.InvalidDataException;
import app.model.Student;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ValidationTests {

    @Test
    void validStudentCreated() {
        Student s = new Student("Ivan", 20);
        assertEquals("Ivan", s.getName());
        assertEquals(20, s.getAge());
    }

    @Test
    void invalidStudentThrowsException() {
        InvalidDataException ex = assertThrows(
                InvalidDataException.class,
                () -> new Student("", -5)
        );

        assertTrue(ex.getErrors().size() >= 2);
    }

    @Test
    void setterValidationWorks() {
        Student s = new Student("Test", 20);

        assertThrows(InvalidDataException.class, () -> s.setAge(0));
        assertThrows(InvalidDataException.class, () -> s.setName(""));
    }
}
