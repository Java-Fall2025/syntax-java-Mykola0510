package app.repository;

import app.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class StudentRepository {

    private static final Logger logger = Logger.getLogger(StudentRepository.class.getName());
    private final List<Student> data = new ArrayList<>();

    public void add(Student s) {
        logger.info("Attempting to add student: " + s);
        data.add(s);
        logger.info("Student added successfully.");
    }

    public List<Student> getAll() {
        return new ArrayList<>(data);
    }
}
