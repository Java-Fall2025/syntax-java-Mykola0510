package app;

import app.exception.InvalidDataException;
import app.model.Student;
import app.repository.StudentRepository;

public class Main {
    public static void main(String[] args) {

        StudentRepository repo = new StudentRepository();

        System.out.println("=== VALID STUDENTS ===");
        try {
            Student s1 = new Student("Oleh", 19);
            repo.add(s1);

            Student s2 = new Student("Anna", 22);
            repo.add(s2);

        } catch (InvalidDataException e) {
            System.out.println("VALIDATION ERROR: " + e.getMessage());
        }

        System.out.println("\n=== INVALID STUDENTS ===");
        try {
            Student bad = new Student("", -1);
            repo.add(bad);
        } catch (InvalidDataException e) {
            System.out.println("ERRORS:");
            e.getErrors().forEach(System.out::println);
        }

        System.out.println("\n=== FINAL REPOSITORY ===");
        repo.getAll().forEach(System.out::println);
    }
}
