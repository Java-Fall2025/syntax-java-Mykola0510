package project;

import java.util.*;
import java.util.logging.*;

public class Main {
    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args){
        DataLoader loader = new DataLoader();
        try{
            List<String> data = loader.load("data.txt");
            log.info("Loaded "+data.size()+" records");
        } catch(Exception e){
            log.severe("Error: "+e.getMessage());
        } finally {
            log.info("Program finished");
        }
    }
}
