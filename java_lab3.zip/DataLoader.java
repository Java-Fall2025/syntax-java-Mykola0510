package project;

import java.io.*;
import java.util.*;
import java.util.logging.*;

public class DataLoader {
    private static final Logger log = Logger.getLogger(DataLoader.class.getName());

    public List<String> load(String path) throws InvalidDataException {
        List<String> list = new ArrayList<>();
        try(BufferedReader br=new BufferedReader(new FileReader(path))) {
            String line;
            while((line=br.readLine())!=null){
                if(line.trim().isEmpty())
                    throw new InvalidDataException("Empty data line");
                list.add(line);
                log.info("Loaded: "+line);
            }
        } catch(FileNotFoundException e){
            log.severe("File not found");
            throw new InvalidDataException("File missing");
        } catch(IOException e){
            log.severe("IO error");
            throw new InvalidDataException("IO problem");
        }
        return list;
    }
}
