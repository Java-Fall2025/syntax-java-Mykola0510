package ua.util;

import ua.model.AccessLevel;

public class LibraryUtils {

    public static String accessDescription(AccessLevel level) {
        return switch (level) {
            case BASIC   -> "Може читати до 3 книг";
            case PREMIUM -> "Може читати до 10 книг";
            case VIP     -> "Необмежений доступ";
        };
    }

    public static int computeLimit(AccessLevel level) {
        return switch (level) {
            case BASIC -> 3;
            case PREMIUM -> 10;
            case VIP -> Integer.MAX_VALUE;
        };
    }
}
