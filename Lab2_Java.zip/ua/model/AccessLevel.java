package ua.model;

public enum AccessLevel {
    BASIC,
    PREMIUM,
    VIP
}
