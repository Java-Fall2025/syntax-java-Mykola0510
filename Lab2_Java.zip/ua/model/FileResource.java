package ua.model;

public record FileResource(String url, String format, double size) { }
