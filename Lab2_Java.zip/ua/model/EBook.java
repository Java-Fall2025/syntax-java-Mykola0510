package ua.model;

import java.util.List;

public record EBook(String title, java.util.List<ua.model.Author> authors, String isbn, java.util.List<ua.model.FileResource> files) { }
