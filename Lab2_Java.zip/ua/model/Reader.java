package ua.model;

public record Reader(String firstName, String lastName, String readerId, AccessLevel accessLevel) { }
