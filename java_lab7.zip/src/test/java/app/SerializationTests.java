package app;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class SerializationTests {

    @Test
    void testJson(){
        List<Student> list=List.of(new Student("A",20), new Student("B",21));
        DataSerializer.saveJson(list, "test.json");
        List<Student> r=DataSerializer.loadJson("test.json", Student.class);
        assertEquals(list, r);
    }

    @Test
    void testYaml(){
        List<Student> list=List.of(new Student("X",18), new Student("Y",19));
        DataSerializer.saveYaml(list, "test.yaml");
        List<Student> r=DataSerializer.loadYaml("test.yaml", Student.class);
        assertEquals(list, r);
    }
}
