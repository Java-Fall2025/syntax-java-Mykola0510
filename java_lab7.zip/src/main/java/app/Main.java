package app;

import java.util.List;

public class Main {
    public static void main(String[] args){
        String json=ConfigLoader.get("json.path");
        String yaml=ConfigLoader.get("yaml.path");
        int count=ConfigLoader.getInt("test.count");

        StudentRepository repo=new StudentRepository();
        for(int i=1;i<=count;i++){
            repo.add(new Student("Student"+i, 18+(i%5)));
        }

        DataSerializer.saveJson(repo.getAll(), json);
        DataSerializer.saveYaml(repo.getAll(), yaml);

        List<Student> fromJson=DataSerializer.loadJson(json, Student.class);
        List<Student> fromYaml=DataSerializer.loadYaml(yaml, Student.class);

        System.out.println("JSON OK = "+fromJson.equals(repo.getAll()));
        System.out.println("YAML OK = "+fromYaml.equals(repo.getAll()));
    }
}
