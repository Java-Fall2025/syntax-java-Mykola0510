package app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class DataSerializer {
    private static final ObjectMapper json = new ObjectMapper();
    private static final YAMLMapper yaml = new YAMLMapper();

    public static <T> void saveJson(List<T> data, String path){
        try{
            json.writerWithDefaultPrettyPrinter().writeValue(new File(path), data);
        }catch(IOException e){ throw new RuntimeException(e); }
    }

    public static <T> void saveYaml(List<T> data, String path){
        try{
            yaml.writerWithDefaultPrettyPrinter().writeValue(new File(path), data);
        }catch(IOException e){ throw new RuntimeException(e); }
    }

    public static <T> List<T> loadJson(String path, Class<T> cls){
        try{
            return json.readValue(new File(path),
                json.getTypeFactory().constructCollectionType(List.class, cls));
        }catch(IOException e){ throw new RuntimeException(e); }
    }

    public static <T> List<T> loadYaml(String path, Class<T> cls){
        try{
            return yaml.readValue(new File(path),
                yaml.getTypeFactory().constructCollectionType(List.class, cls));
        }catch(IOException e){ throw new RuntimeException(e); }
    }
}
