package app;

public class Student implements Comparable<Student> {
    private String name;
    private int age;

    public Student() {}

    public Student(String name, int age){
        this.name=name;
        this.age=age;
    }

    public String getName(){return name;}
    public int getAge(){return age;}

    @Override
    public int compareTo(Student o){
        return this.name.compareTo(o.name);
    }

    @Override
    public boolean equals(Object o){
        if(this==o) return true;
        if(!(o instanceof Student s)) return false;
        return age==s.age && name.equals(s.name);
    }

    @Override
    public int hashCode(){return name.hashCode()+age;}
}
