import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class GenericRepositoryTest {
    @Test
    void testAddFind(){
        GenericRepository<Reader> r=new GenericRepository<>(Reader::readerId);
        Reader x=new Reader("A","B","ID1");
        r.add(x);
        assertTrue(r.findByIdentity("ID1").isPresent());
    }
}