import java.util.*;
import java.util.logging.Logger;
public class GenericRepository<T> {
    private static final Logger logger = Logger.getLogger(GenericRepository.class.getName());
    private final Map<String,T> storage = new HashMap<>();
    private final IdentityExtractor<T> extractor;
    public GenericRepository(IdentityExtractor<T> extractor){this.extractor=extractor;}
    public void add(T item){
        String id = extractor.extractIdentity(item);
        if(storage.containsKey(id)) logger.warning("Duplicate: "+id);
        storage.put(id,item);
        logger.info("Added: "+id);
    }
    public void remove(String id){storage.remove(id);}
    public List<T> getAll(){return new ArrayList<>(storage.values());}
    public Optional<T> findByIdentity(String id){return Optional.ofNullable(storage.get(id));}
}