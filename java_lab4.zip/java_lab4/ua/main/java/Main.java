import java.time.LocalDate;
import java.util.List;
public class Main {
    public static void main(String[] args){
        Author a1=new Author("John","Smith",1980);
        Reader r1=new Reader("Alex","Brown","R001");
        File f1=new File("url",EBookFormat.PDF,1024,EBookType.PUBLIC);
        EBook e=new EBook("Java",List.of(a1),"ISBN1",List.of(f1));
        GenericRepository<Reader> rr=new GenericRepository<>(Reader::readerId);
        rr.add(r1);
        System.out.println(rr.findByIdentity("R001"));
    }
}