import java.util.List;
public class EBook {
    private String title;
    private List<Author> authors;
    private String isbn;
    private List<File> files;
    public EBook(String title, List<Author> authors, String isbn, List<File> files) {
        this.title = title;
        this.authors = authors;
        this.isbn = isbn;
        this.files = files;
    }
    public String getTitle(){return title;}
    public List<Author> getAuthors(){return authors;}
    public String getIsbn(){return isbn;}
    public List<File> getFiles(){return files;}
    public String toString(){return "EBook{title="+title+", isbn="+isbn+"}";}
}