
public class EBook {
    private String title;
    public EBook(String t){ this.title=t; }
    public String getTitle(){ return title; }
}
