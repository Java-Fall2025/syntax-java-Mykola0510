
import java.util.*;
import java.util.stream.*;

public class GenericRepository<T> {
    protected List<T> data = new ArrayList<>();

    public void add(T t){ data.add(t); }
    public List<T> getAll(){ return data; }
}
