
import java.util.*;
import java.util.stream.*;

public class EBookRepository extends GenericRepository<EBook>{
    public List<EBook> findByTitle(String title){
        return data.stream().filter(e-> e.getTitle().equalsIgnoreCase(title)).toList();
    }
}
