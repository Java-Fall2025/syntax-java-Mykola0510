import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
public class SortingTest{
    @Test void testSort(){
        ReaderRepository r=new ReaderRepository();
        r.add(new Reader("A","C","3"));
        r.add(new Reader("A","A","1"));
        r.add(new Reader("A","B","2"));
        List<Reader> sorted=r.sortByLastName();
        assertEquals("A",sorted.get(0).lastName());
        assertEquals("B",sorted.get(1).lastName());
        assertEquals("C",sorted.get(2).lastName());
    }
}