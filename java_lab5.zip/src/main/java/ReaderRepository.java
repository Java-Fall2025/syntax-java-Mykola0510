import java.util.List;
public class ReaderRepository extends GenericRepository<Reader>{
    public ReaderRepository(){super(Reader::readerId);}
    public List<Reader> sortByLastName(){List<Reader> l=getAll(); l.sort(ReaderComparators.byLastName); return l;}
    public List<Reader> sortByFirstName(){List<Reader> l=getAll(); l.sort(ReaderComparators.byFirstName); return l;}
}