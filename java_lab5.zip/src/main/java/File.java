public record File(String url,EBookFormat format,long size,EBookType type)
        implements Comparable<File>{
    @Override public int compareTo(File o){return url.compareTo(o.url());}
}