import java.util.*;import java.util.logging.*;
public class GenericRepository<T>{
    private static final Logger log=Logger.getLogger(GenericRepository.class.getName());
    protected final Map<String,T> storage=new HashMap<>();
    protected final IdentityExtractor<T> extractor;
    public GenericRepository(IdentityExtractor<T> ex){this.extractor=ex;}
    public void add(T item){
        String id=extractor.extractIdentity(item);
        if(storage.containsKey(id)) log.warning("Duplicate "+id);
        storage.put(id,item); log.info("Added "+id);
    }
    public void remove(String id){storage.remove(id);}
    public List<T> getAll(){return new ArrayList<>(storage.values());}
    public Optional<T> findByIdentity(String id){return Optional.ofNullable(storage.get(id));}
    public List<T> sortByIdentity(String order){
        List<T> list=getAll();
        if(order.equalsIgnoreCase("ASC"))
            list.sort((a,b)->extractor.extractIdentity(a).compareTo(extractor.extractIdentity(b)));
        else
            list.sort((a,b)->extractor.extractIdentity(b).compareTo(extractor.extractIdentity(a)));
        return list;
    }
}