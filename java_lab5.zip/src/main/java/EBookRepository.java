import java.util.List;
public class EBookRepository extends GenericRepository<EBook>{
    public EBookRepository(){super(EBook::getIsbn);}
    public List<EBook> sortByTitle(){List<EBook> l=getAll(); l.sort(EBookComparators.byTitle); return l;}
    public List<EBook> sortByAuthorsCount(){List<EBook> l=getAll(); l.sort(EBookComparators.byAuthorsCount); return l;}
}