import java.util.Comparator;
public class EBookComparators{
    public static Comparator<EBook> byTitle=Comparator.comparing(EBook::getTitle);
    public static Comparator<EBook> byAuthorsCount=Comparator.comparingInt(e->e.getAuthors().size());
}