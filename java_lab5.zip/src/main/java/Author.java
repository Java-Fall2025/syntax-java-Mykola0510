public record Author(String firstName,String lastName,int birthYear)
        implements Comparable<Author>{
    @Override public int compareTo(Author o){
        int c=lastName.compareTo(o.lastName);
        return c!=0?c:firstName.compareTo(o.firstName);
    }
}