import java.util.List;
public class EBook implements Comparable<EBook>{
    private String title; private List<Author> authors; private String isbn; private List<File> files;
    public EBook(String title,List<Author> authors,String isbn,List<File> files){
        this.title=title; this.authors=authors; this.isbn=isbn; this.files=files;
    }
    public String getTitle(){return title;}
    public List<Author> getAuthors(){return authors;}
    public String getIsbn(){return isbn;}
    public List<File> getFiles(){return files;}
    @Override public int compareTo(EBook o){return isbn.compareTo(o.isbn);}
    public String toString(){return title+"("+isbn+")";}
}