import java.util.Comparator;
public class ReaderComparators{
    public static Comparator<Reader> byLastName=Comparator.comparing(Reader::lastName);
    public static Comparator<Reader> byFirstName=Comparator.comparing(Reader::firstName);
}