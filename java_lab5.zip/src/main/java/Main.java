import java.util.List;
public class Main{
    public static void main(String[] args){
        ReaderRepository rRepo=new ReaderRepository();
        rRepo.add(new Reader("Alex","Brown","R003"));
        rRepo.add(new Reader("Mike","Anderson","R001"));
        rRepo.add(new Reader("Sarah","Clark","R002"));
        System.out.println("ASC: "+rRepo.sortByIdentity("ASC"));
        System.out.println("ByLast: "+rRepo.sortByLastName());
    }
}