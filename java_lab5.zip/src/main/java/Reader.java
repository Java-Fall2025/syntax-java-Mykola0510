public record Reader(String firstName,String lastName,String readerId)
        implements Comparable<Reader>{
    @Override public int compareTo(Reader o){
        return readerId.compareTo(o.readerId());
    }
}